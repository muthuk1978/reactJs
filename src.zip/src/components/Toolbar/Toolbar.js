import React from 'react';

import "./Toolbar.css";
import DrawerToggleButton from './sideDrawer/DrawerToggleButton';

const toolbar= props =>{
    <header className="toolbar">
        <nav className="toolbar_navigation">
         <div className ="toggle_button_show">
             <DrawerToggleButton click ={props.drawerToggleClickHandler}/>
             </div>
             <div className="toolbar_logo"> <a href="#"> The Logo</a>
             </div>
             <div className="spacer"></div>
             <div className="toolbar_navigation_items">
                 <ul>
                     <li><a href="/"> Products </a> </li>
                     <li><a href="/"> Users </a> </li>
                 </ul>
                 </div>

        </nav>
        </header>

};
export default toolbar;