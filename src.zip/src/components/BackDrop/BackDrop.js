import React from 'react';

import './BackDrop.css';

const backDrop  =props=>{
<div class="backDrop" onClick={props.click}></div>
};