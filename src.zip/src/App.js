import React from 'react';

import Toolbar from './components/Toolbar/Toolbar';
import SideDrawer from './components/sideDrawer/SideDrawer';
import BackDrop  from './components/BackDrop/BackDrop';

export default class App extends React.Component {
  state ={
    sideDrawerOpen=false;
  }

  drawerToggleClickHandler = () => {
    this.setState=((prevState)=> {
    return {sideDrawerOpen:!prevState.sideDrawerOpen }
    });

  }
  backDropClickHandler =() =>{
    this.setState({sideDrawerOpen: false});

  };
    render() {
      let backDrop;

      if(this.state.sideDrawerOpen){
        backDrop = <BackDrop click ={this.backDropClickHandler}/>;
      }

      return (
      <div style={{height: '100%'}}>
      <Toolbar drawerToggleClickHandler={this.drawerToggleClickHandler}/>
      <SideDrawer show={this.state.sideDrawerOpen}/>
      {backDrop}
      <main style={{marginTop: "64px"}}><p> This is page</p></main>
      
      </div>
      )
    }
  }